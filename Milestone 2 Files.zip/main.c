#include <stdint.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/io.h>
#include "lcd_driver.h"
#include "port_macros.h"
#define PWM_TOP 255
#define F_CPU 20000000
#define LEFT_BUTTON 0x02
#define MIDDLE_BUTTON 0x10
#define RIGHT_BUTTON 0x20
#define MOTOR1_BIT0 0x40
#define MOTOR1_BIT1 0x20
#define MOTOR2_BITS 0x08
#define BUTTONS PINB
#define MOTOR1 PORTD
#define MOTOR2 PORTB
#define LEFT_SENSOR 0x01
#define LEFT_MIDDLE_SENSOR 0x02
#define MIDDLE_SENSOR 0x04
#define RIGHT_MIDDLE_SENSOR 0x08
#define RIGHT_SENSOR 0x010
#define SENSORS PINC

void displayLCD(char* input);
int speedselect();
int numberofbunkers();
int sensingline();
void forward();
void reverse();
void clockwise();
void counterclockwise();
void brake();
void motors(int directionindex1, int speedindex1, int duration1);

int main(){
    DDRB &= ~(LEFT_BUTTON|MIDDLE_BUTTON|RIGHT_BUTTON);
    PORTB |= (LEFT_BUTTON|MIDDLE_BUTTON|RIGHT_BUTTON); //pull-up resistor
    DDRB |= MOTOR2_BITS;
    DDRD |= MOTOR2_BITS|MOTOR1_BIT1|MOTOR1_BIT0;
    DDRC &= ~(LEFT_SENSOR|LEFT_MIDDLE_SENSOR|MIDDLE_SENSOR|RIGHT_MIDDLE_SENSOR|RIGHT_SENSOR);
    PORTC |= (LEFT_SENSOR|LEFT_MIDDLE_SENSOR|MIDDLE_SENSOR|RIGHT_MIDDLE_SENSOR|RIGHT_SENSOR);
    char bunkerdisplay[20];
    char finishdisplay[20] = {"Good Job!"};
    int numofbunkers = numberofbunkers();
    int speed = speedselect();
    int turnspeed = 6000;
    int bunkercount = 0;
    while(bunkercount < numofbunkers){
    int sensorscore = sensingline();
        if(speed == 0){
             turnspeed = 5700;
        }            
	if(speed == 1){
             turnspeed = 3000;
        }
	if(speed == 2){
             turnspeed = 2000;
        }
        if(sensorscore == 0){
            motors(0, speed, 10);
        }
        else if(sensorscore > 7){
            motors(2, speed, turnspeed);
        }
        else if((sensorscore <= 7) & (sensorscore > 0)){
            motors(0, 0, 2000);
	    sensorscore = sensingline();
            if(sensorscore > 7){
                motors(2, speed, turnspeed);
                motors(0, speed, 500);
            }
            else{
                bunkercount++;
                sprintf(bunkerdisplay, "%d", bunkercount);
                displayLCD(bunkerdisplay);
                motors(4, speed, 4000);
                motors(3, speed, turnspeed);
            }
        }
    }
    displayLCD(finishdisplay);
    return 0;
}

int sensingline(){
    unsigned int left_sensor_sense = (SENSORS &(LEFT_SENSOR));
    unsigned int middle_left_sensor_sense = (SENSORS &(LEFT_MIDDLE_SENSOR));
    unsigned int middle_sensor_sense = (SENSORS &(MIDDLE_SENSOR));
    unsigned int middle_right_sensor_sense = (SENSORS &(RIGHT_MIDDLE_SENSOR));
    unsigned int right_sensor_sense = (SENSORS &(RIGHT_SENSOR));
    int sense_score = 0;
    int sense0 = 0;
    int sense1 = 0;
    int sense2 = 0;
    int sense3 = 0;
    int sense4 = 0;
    if(left_sensor_sense == 1){
        sense0 = 2;
    }
    if(left_sensor_sense == 0){
        sense0 = 0;
    }
    if(middle_left_sensor_sense == 2){
        sense1 = 2;
    }
    if(middle_left_sensor_sense == 0){
        sense1 = 0;
    }
    if(middle_sensor_sense == 4){
        sense2 = 2;
    }
    if(middle_sensor_sense == 0){
        sense2 = 0;
    }
    if(middle_right_sensor_sense == 8){
        sense3 = 2;
    }
    if(middle_right_sensor_sense == 0){
        sense3 = 0;
    }
    if(right_sensor_sense == 16){
        sense4 = 2;
    }
    if(right_sensor_sense == 0){
        sense4 = 0;
    }
    sense_score = sense0 + sense1 + sense2 + sense3 + sense4;
    return sense_score;
}

void displayLCD(char* input){
    initialize_LCD_driver();
    LCD_execute_command(TURN_ON_DISPLAY);
    LCD_execute_command(CLEAR_DISPLAY);
    LCD_print_String(input);
}

int numberofbunkers(){
    unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
    unsigned int left_button_pressed = 0;
    unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
    unsigned int middle_button_pressed = 0;
    unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
    unsigned int right_button_pressed = 0;
    int numberindex = 1;
    char display[20];
    sprintf(display, "%d Bunkers", numberindex);
    displayLCD(display);
    while(1){
        if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
            if((BUTTONS &(LEFT_BUTTON)) == 0){
                left_button_pressed = 1;
            }
            last_left_button_state =(BUTTONS &(LEFT_BUTTON));
        }
        else{
            left_button_pressed = 0;
        }
        if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
            if((BUTTONS &(MIDDLE_BUTTON)) == 0){
                middle_button_pressed = 1;
            }
            last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
        }
        else{
            middle_button_pressed = 0;
        }
        if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
            if((BUTTONS &(RIGHT_BUTTON)) == 0){
                right_button_pressed = 1;
            }
            last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
        }
        else{
            right_button_pressed = 0;
        }
        if(left_button_pressed == 1){
            if(numberindex == 1){
                numberindex = 6;
            }
            numberindex--;
            sprintf(display, "%d Bunkers", numberindex);
            displayLCD(display);
        }
        if(right_button_pressed == 1){
            if(numberindex == 5){
                numberindex = 0;
            }
            numberindex++;
            sprintf(display, "%d Bunkers", numberindex);
            displayLCD(display);
        }
        if(middle_button_pressed == 1){
            break;
        }
    }
    return numberindex;
}

int speedselect(){
    unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
    unsigned int left_button_pressed = 0;
    unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
    unsigned int middle_button_pressed = 0;
    unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
    unsigned int right_button_pressed = 0;
    int speedindex = 0;
    char* speedchar[3] = {"Slow","Medium","Fast"};
    displayLCD(speedchar[speedindex]);
    while(1){
        if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
            if((BUTTONS &(LEFT_BUTTON)) == 0){
                left_button_pressed = 1;
            }
            last_left_button_state =(BUTTONS &(LEFT_BUTTON));
        }
        else{
            left_button_pressed = 0;
        }
        if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
            if((BUTTONS &(MIDDLE_BUTTON)) == 0){
                middle_button_pressed = 1;
            }
            last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
        }
        else{
            middle_button_pressed = 0;
        }
        if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
            if((BUTTONS &(RIGHT_BUTTON)) == 0){
                right_button_pressed = 1;
            }
            last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
        }
        else{
            right_button_pressed = 0;
        }
        if(left_button_pressed == 1){
            if(speedindex == 0){
                speedindex = 3;
            }
            speedindex--;
            displayLCD(speedchar[speedindex]);
        }
        if(right_button_pressed == 1){
            if(speedindex == 2){
                speedindex = -1;
            }
            speedindex++;
            displayLCD(speedchar[speedindex]);
        }
        if(middle_button_pressed == 1){
            break;
        }
    }
    return speedindex;
}

void forward(){
    MOTOR1 &= ~(MOTOR1_BIT1);
    MOTOR1 |= (MOTOR1_BIT0);
    MOTOR1 &= ~(MOTOR2_BITS);
    MOTOR2 |= (MOTOR2_BITS);
}

void reverse(){
    MOTOR1 |= (MOTOR1_BIT1);
    MOTOR1 &= ~(MOTOR1_BIT0);
    MOTOR1 |= (MOTOR2_BITS);
    MOTOR2 &= ~(MOTOR2_BITS);
}

void clockwise(){
    MOTOR1 &= ~(MOTOR1_BIT1);
    MOTOR1 |= (MOTOR1_BIT0);
    MOTOR1 |= (MOTOR2_BITS);
    MOTOR2 &= ~(MOTOR2_BITS);
}

void counterclockwise(){
    MOTOR1 |= (MOTOR1_BIT1);
    MOTOR1 &= ~(MOTOR1_BIT0);
    MOTOR1 &= ~(MOTOR2_BITS);
    MOTOR2 |= (MOTOR2_BITS);
}

void brake(){
    MOTOR1 |= (MOTOR1_BIT1);
    MOTOR1 |= (MOTOR1_BIT0);
    MOTOR1 |= (MOTOR2_BITS);
    MOTOR2 |= (MOTOR2_BITS);
}

void motors(int directionindex1, int speedindex1, int duration1){
    unsigned int pwm_counter = 0;
    unsigned long int count = 0;
    unsigned long int duration = duration1;
    int duty_cycle;
    int delay;
    if (speedindex1 == 0){
        duty_cycle = 20;
        delay = 1;
    }
    if (speedindex1 == 1){
        duty_cycle = 30;
        delay = 1;
    }
    if (speedindex1 == 2){
        duty_cycle = 40;
        delay = 1;
    }
    while(count < 100*duration){
        count++;
        //PWM Counter
        pwm_counter = pwm_counter + 1;
        if( pwm_counter >= PWM_TOP ){
            pwm_counter = 0;
        }

        // Forward    
        if(directionindex1 == 0){
            if(pwm_counter < duty_cycle){
                forward();
            }
            else{
                brake();
            }
        }
    
        // Reverse    
        if(directionindex1 == 1){
            if(pwm_counter < duty_cycle){
                reverse();
            }
            else{
                brake();
            }
        }
    
        // Clockwise    
        if(directionindex1 == 2){
            if(pwm_counter < duty_cycle){
                clockwise();
            }
            else{
                brake();
            }
        }
    
        // Counter Clockwise    
        if(directionindex1 == 3){
            if(pwm_counter < duty_cycle){
                counterclockwise();
            }
            else{
                brake();
            }
        }
        
        // Stop
        if(directionindex1 == 4){
            brake();
        }
        _delay_us(delay);
    }
}