#include <stdint.h>
#include <stdio.h> 
#include <util/delay.h>
#include <avr/io.h>
#include "lcd_driver.h"
#include "port_macros.h"
#define PWM_TOP 255
#define F_CPU 20000000
#define LEFT_BUTTON 0x02
#define MIDDLE_BUTTON 0x10
#define RIGHT_BUTTON 0x20
#define MOTOR1_BIT0 0x40
#define MOTOR1_BIT1 0x20
#define MOTOR2_BITS 0x08
#define BUTTONS PINB
#define MOTOR1 PORTD
#define MOTOR2 PORTB

void displayLCD(char* input);
int directionselect();
int speedselect();
int durationselect();
void executecommand(int directionindex1, int speedindex1, int durationindex1);
int numberofcommands();

int main(){
	DDRB &= ~(LEFT_BUTTON|MIDDLE_BUTTON|RIGHT_BUTTON);
	PORTB |= (LEFT_BUTTON|MIDDLE_BUTTON|RIGHT_BUTTON); //pull-up resistor
	DDRB |= MOTOR2_BITS;
	DDRD |= MOTOR2_BITS|MOTOR1_BIT1|MOTOR1_BIT0;
	while(1){
		int direction[4];
		int speed[4];
		int durationsel[4];
		int numofcommands = numberofcommands();
		for(int n = 0; n < numofcommands; n++){
			direction[n] = directionselect();
			speed[n] = speedselect();
			durationsel[n] = durationselect();
		}
		for(int m = 0; m < numofcommands; m++){
			executecommand(direction[m], speed[m], durationsel[m]);
			_delay_us(100);
		}
		MOTOR1 &= ~(MOTOR1_BIT1);
		MOTOR1 &= ~(MOTOR1_BIT0);
		MOTOR1 &= ~(MOTOR2_BITS);
		MOTOR2 &= ~(MOTOR2_BITS);
	}
	return 0;
}

void displayLCD(char* input){
	initialize_LCD_driver();
	LCD_execute_command(TURN_ON_DISPLAY);
	LCD_execute_command(CLEAR_DISPLAY);
	LCD_print_String(input);
}

int numberofcommands(){
	unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
	unsigned int left_button_pressed = 0;
	unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
	unsigned int middle_button_pressed = 0;
	unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
	unsigned int right_button_pressed = 0;
	int numberindex = 1;
	char display[20];
	sprintf(display, "%d Comm.", numberindex);
	displayLCD(display);
	while(1){
		if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
			if((BUTTONS &(LEFT_BUTTON)) == 0){
				left_button_pressed = 1;
			}
			last_left_button_state =(BUTTONS &(LEFT_BUTTON));
		}
		else{
			left_button_pressed = 0;
		}
		if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
			if((BUTTONS &(MIDDLE_BUTTON)) == 0){
				middle_button_pressed = 1;
			}
			last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
		}
		else{
			middle_button_pressed = 0;
		}
		if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
			if((BUTTONS &(RIGHT_BUTTON)) == 0){
				right_button_pressed = 1;
			}
			last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
		}
		else{
			right_button_pressed = 0;
		}
		if(left_button_pressed == 1){
			if(numberindex == 1){
				numberindex = 5;
			}
			numberindex--;
			sprintf(display, "%d Comm.", numberindex);
			displayLCD(display);
		}
		if(right_button_pressed == 1){
			if(numberindex == 4){
				numberindex = 0;
			}
			numberindex++;
			sprintf(display, "%d Comm.", numberindex);
			displayLCD(display);
		}
		if(middle_button_pressed == 1){
			break;
		}
	}
	return numberindex;
}

int directionselect(){
	unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
	unsigned int left_button_pressed = 0;
	unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
	unsigned int middle_button_pressed = 0;
	unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
	unsigned int right_button_pressed = 0;
	int directionindex = 0;
	char* direction[4] = {"F","R","CW","CCW"};
	displayLCD(direction[directionindex]);
	while(1){
		if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
			if((BUTTONS &(LEFT_BUTTON)) == 0){
				left_button_pressed = 1;
			}
			last_left_button_state =(BUTTONS &(LEFT_BUTTON));
		}
		else{
			left_button_pressed = 0;
		}
		if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
			if((BUTTONS &(MIDDLE_BUTTON)) == 0){
				middle_button_pressed = 1;
			}
			last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
		}
		else{
			middle_button_pressed = 0;
		}
		if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
			if((BUTTONS &(RIGHT_BUTTON)) == 0){
				right_button_pressed = 1;
			}
			last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
		}
		else{
			right_button_pressed = 0;
		}
		if(left_button_pressed == 1){
			if(directionindex == 0){
				directionindex = 4;
			}
			directionindex--;
			displayLCD(direction[directionindex]);
		}
		if(right_button_pressed == 1){
			if(directionindex == 3){
				directionindex = -1;
			}
			directionindex++;
			displayLCD(direction[directionindex]);
		}
		if(middle_button_pressed == 1){
			break;
		}
	}
	return directionindex;
}

int speedselect(){
	unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
	unsigned int left_button_pressed = 0;
	unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
	unsigned int middle_button_pressed = 0;
	unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
	unsigned int right_button_pressed = 0;
	int speedindex = 0;
	char* speed[3] = {"Slow","Medium","Fast"};
	displayLCD(speed[speedindex]);
	while(1){
		if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
			if((BUTTONS &(LEFT_BUTTON)) == 0){
				left_button_pressed = 1;
			}
			last_left_button_state =(BUTTONS &(LEFT_BUTTON));
		}
		else{
			left_button_pressed = 0;
		}
		if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
			if((BUTTONS &(MIDDLE_BUTTON)) == 0){
				middle_button_pressed = 1;
			}
			last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
		}
		else{
			middle_button_pressed = 0;
		}
		if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
			if((BUTTONS &(RIGHT_BUTTON)) == 0){
				right_button_pressed = 1;
			}
			last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
		}
		else{
			right_button_pressed = 0;
		}
		if(left_button_pressed == 1){
			if(speedindex == 0){
				speedindex = 3;
			}
			speedindex--;
			displayLCD(speed[speedindex]);
		}
		if(right_button_pressed == 1){
			if(speedindex == 2){
				speedindex = -1;
			}
			speedindex++;
			displayLCD(speed[speedindex]);
		}
		if(middle_button_pressed == 1){
			break;
		}
	}
	return speedindex;
}

int durationselect(){
	unsigned int last_left_button_state = (BUTTONS &(LEFT_BUTTON));
	unsigned int left_button_pressed = 0;
	unsigned int last_middle_button_state = (BUTTONS &(MIDDLE_BUTTON));
	unsigned int middle_button_pressed = 0;
	unsigned int last_right_button_state = (BUTTONS &(RIGHT_BUTTON));
	unsigned int right_button_pressed = 0;
	int durationindex = 100;
	char display[10];
	sprintf(display, "%d ms", durationindex);
	displayLCD(display);
	while(1){
		if((BUTTONS &(LEFT_BUTTON)) != last_left_button_state){
			if((BUTTONS &(LEFT_BUTTON)) == 0){
				left_button_pressed = 1;
			}
			last_left_button_state =(BUTTONS &(LEFT_BUTTON));
		}
		else{
			left_button_pressed = 0;
		}
		if((BUTTONS &(MIDDLE_BUTTON)) != last_middle_button_state){
			if((BUTTONS &(MIDDLE_BUTTON)) == 0){
				middle_button_pressed = 1;
			}
			last_middle_button_state =(BUTTONS &(MIDDLE_BUTTON));
		}
		else{
			middle_button_pressed = 0;
		}
		if((BUTTONS &(RIGHT_BUTTON)) != last_right_button_state){
			if((BUTTONS &(RIGHT_BUTTON)) == 0){
				right_button_pressed = 1;
			}
			last_right_button_state =(BUTTONS &(RIGHT_BUTTON));
		}
		else{
			right_button_pressed = 0;
		}
		if(left_button_pressed == 1 && durationindex != 0){
			durationindex = durationindex - 100;
			sprintf(display, "%d ms", durationindex);
			displayLCD(display);
		}
		if(right_button_pressed == 1 && durationindex != 5000){
			durationindex = durationindex + 100;
			sprintf(display, "%d ms", durationindex);
			displayLCD(display);
		}
		if(middle_button_pressed == 1){
			break;
		}
	}
	return durationindex;
}

void executecommand(int directionindex1, int speedindex1, int durationindex1){
	unsigned int pwm_counter = 0;
	unsigned long int count = 0;
	unsigned long int duration = durationindex1;
	int duty_cycle;
	if (speedindex1 == 0){
		duty_cycle = 30;
	}
	if (speedindex1 == 1){
		duty_cycle = 80;
	}
	if (speedindex1 == 2){
		duty_cycle = 130;
	}
	while(count < 100*duration){
		count++;
		//PWM Counter
		pwm_counter = pwm_counter + 1;
		if( pwm_counter >= PWM_TOP ){
			pwm_counter = 0;
		}

		// Forward	
		if(directionindex1 == 0){
			if(pwm_counter < duty_cycle){
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 |= (MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 |= (MOTOR2_BITS);
			}
			else{
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
		}
	
		// Reverse	
		if(directionindex1 == 1){
			if(pwm_counter < duty_cycle){
				MOTOR1 |= (MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 |= (MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
			else{
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
		
		}
	
		// Clockwise	
		if(directionindex1 == 2){
			if(pwm_counter < duty_cycle){
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 |= (MOTOR1_BIT0);
				MOTOR1 |= (MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
			else{
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
	
		}
	
		// Counter Clockwise	
		if(directionindex1 == 3){
			if(pwm_counter < duty_cycle){
				MOTOR1 |= (MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 |= (MOTOR2_BITS);
			}
			else{
				MOTOR1 &= ~(MOTOR1_BIT1);
				MOTOR1 &= ~(MOTOR1_BIT0);
				MOTOR1 &= ~(MOTOR2_BITS);
				MOTOR2 &= ~(MOTOR2_BITS);
			}
		}
		_delay_us(10);
	}
}