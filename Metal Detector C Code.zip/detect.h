#include <stdint.h>
#ifndef DETECT_H
#define DETECT_H
	uint32_t detect(uint32_t frequency);
	void update_LED(uint32_t sample);
#endif
