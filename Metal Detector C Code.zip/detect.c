#include "detect.h"
#include "delay.h"
#include <stdint.h>

#define LED_PORT (*(unsigned volatile *)0x40000008)

#define NO_WASHER 0xA8000
#define SMALL_WASHER 0xA7500
#define MEDIUM_WASHER 0xA6000
#define LARGE_WASHER 0xA0000

uint32_t detect(uint32_t frequency){
	uint32_t sample[10];
	uint8_t i = 0;

	while(i < 10)
	{
		sample[i] = frequency;
		if((i > 0) && (sample[i] - sample[i-1] >= 0x10000))
		{
			i = 0;
			continue;
		}
		update_LED(sample[i]);
		delay_ms(100);
		i++;
	}

	uint32_t average = (sample[0] + sample[1] + sample[2] + sample[3] + sample[4] + sample[5] + sample[6] + sample[7] + sample[8] + sample[9]) / 10;
	return average;
}


void update_LED(uint32_t sample)
{
	if (sample >= NO_WASHER)
		LED_PORT &= 0x0000;

	else if (sample >= SMALL_WASHER)
	{
		LED_PORT &= 0x0000;
		LED_PORT |= 0x8000;
	}

	else if (sample >= MEDIUM_WASHER)
	{
		LED_PORT &= 0x0000;
		LED_PORT |= 0xC000;

	}

	else if (sample >= LARGE_WASHER)
	{
		LED_PORT &= 0x0000;
		LED_PORT |= 0xE000;
	}

}
