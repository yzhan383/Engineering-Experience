#include "delay.h"
#include "xparameters.h"

#define DELAY_PER_US (XPAR_MICROBLAZE_CORE_CLOCK_FREQ_HZ/1000000)
#define DELAY_PER_MS (XPAR_MICROBLAZE_CORE_CLOCK_FREQ_HZ/1000)

void delay_1us()
{
	delay_cycles(DELAY_PER_US/4);
}

void delay_us(unsigned t)
{
	while(t--)
		delay_1us();
}

void delay_1ms()
{
	delay_cycles(DELAY_PER_MS/4);
}

void delay_ms(unsigned t)
{
	while(t--)
		delay_1ms();
}
