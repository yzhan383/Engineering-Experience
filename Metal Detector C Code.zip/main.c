#include <xparameters.h>
#include <xil_printf.h>
#include <stdint.h>
#include <stdbool.h>

#include "delay.h"
#include "detect.h"

#define SW_PORT (*(unsigned volatile *)0x40000000)
#define LED_PORT (*(unsigned volatile *)0x40000008)
#define SSEG ((unsigned volatile *)0x44A00000)

#define FREQUENCY (*(unsigned volatile *)0x44A10000)
#define SIGNAL (*(unsigned volatile *)0x44A20258)

#define NO_WASHER 0xA8000
#define SMALL_WASHER 0xA7500
#define MEDIUM_WASHER 0xA6000
#define LARGE_WASHER 0xA0000

uint8_t seg_lut[16] = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78,
                       0x00, 0x18, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};

int main()
{
	SSEG[0] = seg_lut[0];
	SSEG[1] = seg_lut[0];
	SSEG[2] = seg_lut[0];
	SSEG[3] = seg_lut[0];

	uint8_t small_cntr = 0;
	uint8_t medium_cntr = 0;
	uint8_t large_cntr = 0;
	uint8_t total_cntr = 0;
	while(1){
		static enum {NOTHING, SMALL, MEDIUM, LARGE} state;
		switch(state){
		default:
			case NOTHING:
				xil_printf("Currently reading: Nothing\n");
				if (detect(FREQUENCY) >= NO_WASHER)
					state = NOTHING;
				else if (detect(FREQUENCY) >= SMALL_WASHER){
					small_cntr = (small_cntr + 1) % 16;
					state = SMALL;
				}
				else if (detect(FREQUENCY) >= MEDIUM_WASHER){
					medium_cntr = (medium_cntr + 1) % 16;
					state = MEDIUM;
				}
				else if (detect(FREQUENCY) >= LARGE_WASHER){
					large_cntr = (large_cntr + 1) % 16;
					state = LARGE;
				}
				else{
					state = NOTHING;
				}
				break;

			case SMALL:
				xil_printf("Currently reading: Small Washer\n");
				if(detect(FREQUENCY) >= NO_WASHER)
					state = NOTHING;
				else{
					state = SMALL;
				}
				break;

			case MEDIUM:
				xil_printf("Currently reading: Medium Washer\n");
				if(detect(FREQUENCY) >= NO_WASHER)
					state = NOTHING;
				else{
					state = MEDIUM;
				}
				break;

			case LARGE:
				xil_printf("Currently reading: Large Washer\n");
				if(detect(FREQUENCY) >= NO_WASHER)
					state = NOTHING;
				else{
					state = LARGE;
				}
				break;
		}
		total_cntr = small_cntr + medium_cntr + large_cntr;
		SSEG[0] = seg_lut[total_cntr];
		SSEG[1] = seg_lut[large_cntr];
		SSEG[2] = seg_lut[medium_cntr];
		SSEG[3] = seg_lut[small_cntr];
		xil_printf("freq: %x\n\n", FREQUENCY); //measures the # clock cycles that pass for a given sample range
	}
	return 0;
}
