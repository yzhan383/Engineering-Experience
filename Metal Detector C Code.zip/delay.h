#ifndef DELAY_H
#define DELAY_H

	void delay_1us();
	void delay_us(unsigned t);
	void delay_1ms();
	void delay_ms(unsigned t);
	void delay_cycles(unsigned cycle_count_div_4);

#endif
