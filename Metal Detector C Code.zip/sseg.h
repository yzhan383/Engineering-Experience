#ifndef HEADER
#define HEADER

#include <stdbool.h>
#include <stdint.h>
#include "delay.h"
#define SSEG ((unsigned volatile *)0x44A00000) // seg
#define AN_PORT (*(unsigned volatile *)0x44A00008) // an


uint8_t seg_decoder(uint8_t dig_in);
void write_seg(uint8_t num_in, uint8_t position);
uint8_t write_seg_hex(uint8_t num_in);
uint8_t write_seg_dec(uint8_t num_in);
void turn_off();


#endif


