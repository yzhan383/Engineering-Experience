#include "sseg.h"


uint8_t seg_decoder(uint8_t dig_in){
	uint8_t dig_out;
	// Switch statement to "demux" the input
	switch(dig_in){
		case 0:
			dig_out = 0b01000000;
		break;
		case 1:
			dig_out = 0b01111001;
		break;
		case 2:
			dig_out = 0b00100100;
		break;
		case 3:
			dig_out = 0b00110000;
		break;
		case 4:
			dig_out = 0b00011001;
		break;
		case 5:
			dig_out = 0b00010010;
		break;
		case 6:
			dig_out = 0b00000010;
		break;
		case 7:
			dig_out = 0b01111000;
		break;
		case 8:
			dig_out = 0b00000000;
		break;
		case 9:
			dig_out = 0b00011000;
		break;
		case 10:
			dig_out = 0b00001000;
		break;
		case 11:
			dig_out = 0b00000011;
		break;
		case 12:
			dig_out = 0b01000110;
		break;
		case 13:
			dig_out = 0b00100001;
		break;
		case 14:
			dig_out = 0b00000110;
		break;
		default:
			dig_out = 0b00001110;
		break;
	}
	return dig_out;
}

uint8_t write_seg_dec(uint8_t num_in){
	// Writes an 8 bit number to 7 segment display in decimal
	uint8_t num1_out, num2_out;

	// Decodes first digit of num_in in O(1)
	if (num_in==100)
		num1_out = 0;
	else if (num_in>89)
		num1_out = 9;
	else if (num_in>79)
		num1_out = 8;
	else if (num_in>69)
		num1_out = 7;
	else if (num_in>59)
		num1_out = 6;
	else if (num_in>49)
		num1_out = 5;
	else if (num_in>39)
		num1_out = 4;
	else if (num_in>29)
		num1_out = 3;
	else if (num_in>19)
		num1_out = 2;
	else if (num_in>9)
		num1_out = 1;
	else
		num1_out = 0;

	// Removes tens place digit to be left with ones place
	num2_out = (num_in==100)?0:num_in - (10*num1_out);

	// Decodes
	num1_out = seg_decoder(num1_out);
	num2_out = seg_decoder(num2_out);

	// Writes each digit to the display
	//write_seg(num2_out, (right)?1:3);
	//delay_ms(1);
	//write_seg(num1_out, (right)?2:4);
	//delay_ms(1);
	return (num1_out<<8)|num2_out;


}

uint8_t write_seg_hex(uint8_t num_in){
	// Writes an 8 bit number to 7 segment display in hex
	uint8_t ones_place, sixteens_place;
	ones_place= num_in & 0x000F; // Grabs ones place of input
	sixteens_place = (num_in & 0x00F0) >> 4; // Grabs sixteens place of input

	ones_place = seg_decoder(ones_place);
	sixteens_place = seg_decoder(sixteens_place);

	return (sixteens_place<<8)|ones_place;

	//write_seg(ones_place, (right)?1:3);
	//delay_ms(1);
	//write_seg(sixteens_place, (right)?2:4);
	//delay_ms(1);


}





